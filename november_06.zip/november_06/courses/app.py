from flask import Flask, jsonify, request

app = Flask(__name__)

courses = []

@app.route('/courses', methods=['GET'])
def get_courses():
    return jsonify(courses), 200

@app.route('/courses', methods=['POST'])
def add_course(name):
    data = request.get_json()
    if 'name' not in data:
        return jsonify({"error": "Field 'name' is required"}), 400
    course = {"id": len(courses) + 1, "name": name}
    courses.append(course)
    return jsonify(course), 201

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
