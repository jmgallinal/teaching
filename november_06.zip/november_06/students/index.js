const { ApolloServer } = require('apollo-server');
const bodyParser = require('body-parser');
const studentController = require("./studentController");
const { gql } = require('apollo-server');

const typeDefs = gql`
  type Query {
    getStudents: [Student]
  }
  type Mutation {
    addStudent(name: String!): Student
  }
  type Student {
    id: ID
    name: String
  }
`;

const resolvers = {
  Query: {
    getStudents: studentController.getStudents
  },
  Mutation: {
    addStudent: studentController.addStudent,
  },
};

const server = new ApolloServer({ typeDefs, resolvers });


const PORT = process.env.PORT || 4000;

server.listen(PORT).then(({ url }) => {
  console.log(`Distributed systems GraphQL server: ${url}`);
});