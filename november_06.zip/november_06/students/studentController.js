const students = [];

const getStudents = () => {
  return students;
};

const addStudent = (name) => {
  const student = { id: students.length + 1, name };
  students.push(student);
  return student;
};

module.exports = { getStudents, addStudent };
