import logging
from flask import Flask, jsonify
from prometheus_client import start_http_server, Counter

products = [
    {
        'name': 'product1',
        'description': 'First Product',
        'price': '10'
    }, {
        'name': 'product2',
        'description': 'Second Product',
        'price': '20'
    }
]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

REQUEST_COUNT = Counter('products_requests', 'Total requests to /products')

@app.route('/products', methods=['GET'])
def get_products():
    REQUEST_COUNT.inc()
    logger.info('[Microservice2] GET /products invoked')
    return jsonify({'products': products})

if __name__ == '__main__':
    start_http_server(8000)
    app.run(host='0.0.0.0', port=5001)
