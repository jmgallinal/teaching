import logging
from flask import Flask, jsonify
from prometheus_client import start_http_server, Counter

users = [
    {
        'name': 'user1',
        'email': 'user1@test.com',
    }, {
        'name': 'user2',
        'email': 'user2@test.com',
    }
]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

REQUEST_COUNT = Counter('users_requests', 'Total requests to /users')

@app.route('/users', methods=['GET'])
def get_users():
    REQUEST_COUNT.inc()
    logger.info('[Microservice1] GET /users invoked')
    return jsonify({'users': users})

if __name__ == '__main__':
    start_http_server(8001)
    app.run(host='0.0.0.0', port=5000)